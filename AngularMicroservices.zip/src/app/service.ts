import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
providedIn:"root"
})
export class Service{

    baseUrl="http://localhost:8080/students";
    baseUrl2="http://localhost:8000/finalStudentDetails"
constructor(private http:HttpClient){

}

getStudents():Observable<any>{
    return this.http.get(`${this.baseUrl}`);
}

createStudent(value:object):Observable<Object>{
    return this.http.post(`${this.baseUrl}`,value);
}


postDetails(value:object,id:number):Observable<Object>{
    return this.http.post(`${this.baseUrl2}/${id}`,value);
}

completeDetailsOfStudent(id:number):Observable<Object>{
    return this.http.get(`${this.baseUrl2}/${id}`);
}

}