import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExtraDeatailsComponent } from './extra-deatails.component';

describe('ExtraDeatailsComponent', () => {
  let component: ExtraDeatailsComponent;
  let fixture: ComponentFixture<ExtraDeatailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExtraDeatailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExtraDeatailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
