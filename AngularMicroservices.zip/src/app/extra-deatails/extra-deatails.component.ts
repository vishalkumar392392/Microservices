import { Component, OnInit } from '@angular/core';
import { FinalStudentDetails } from '../finalStudentDetails';
import { Router, ActivatedRoute } from '@angular/router';
import { Service } from '../service';

@Component({
  selector: 'app-extra-deatails',
  templateUrl: './extra-deatails.component.html',
  styleUrls: ['./extra-deatails.component.css']
})
export class ExtraDeatailsComponent implements OnInit {

  id:number;
  studentDetails:FinalStudentDetails = new FinalStudentDetails();
  constructor(private router:Router,private route:ActivatedRoute,private studentService:Service) { }

  ngOnInit() {

   this.id= this.route.snapshot.params['id'];
  }

  onSubmit(){

    this.studentService.postDetails(this.studentDetails,this.id).subscribe(data=>console.log(data));
    this.router.navigate([""]);

  }
  

}
