export class Student{
    id:number;
    firstName:string;
    lastName:string;
    dateOfBirth:Date;
    className:number;
    port:number;
}