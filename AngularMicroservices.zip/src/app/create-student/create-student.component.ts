import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { HttpClient } from '@angular/common/http';
import { Service } from '../service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-student',
  templateUrl: './create-student.component.html',
  styleUrls: ['./create-student.component.css']
})
export class CreateStudentComponent implements OnInit {

  student:Student =new Student();
  constructor(private http:HttpClient,private studentService:Service,private router:Router) { }

  ngOnInit() {
  }
  onSubmit(){
    
     this.studentService.createStudent(this.student).subscribe(data=>console.log(data));
     this.student=new Student();
     this.router.navigate([""]);

  }
}
