import { Component, OnInit } from '@angular/core';
import { Service } from '../service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcome-student',
  templateUrl: './welcome-student.component.html',
  styleUrls: ['./welcome-student.component.css']
})
export class WelcomeStudentComponent implements OnInit {

  students;
  constructor(private studentService:Service,private router:Router) { }

  ngOnInit() {
    this.reload();
  }

  reload(){
    this.studentService.getStudents().subscribe(data=>{
      this.students=data;
    })
  }

  addDetails(id:number){

    this.router.navigate(["details",id])

  }
  completeDetails(id:number){
    this.router.navigate(["completeDetails",id])
  }

}
