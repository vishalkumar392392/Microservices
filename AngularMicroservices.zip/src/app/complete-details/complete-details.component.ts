import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Service } from '../service';
import { FinalStudentDetails } from '../finalStudentDetails';

@Component({
  selector: 'app-complete-details',
  templateUrl: './complete-details.component.html',
  styleUrls: ['./complete-details.component.css']
})
export class CompleteDetailsComponent implements OnInit {

  id:number;
  finalDeatils:any= new FinalStudentDetails();
  constructor(private route:ActivatedRoute,private studentService:Service) { }

  ngOnInit() {

     this.id=  this.route.snapshot.params['id'];
     this.studentService.completeDetailsOfStudent(this.id).subscribe(data=>{
       this.finalDeatils = data;
       console.log(data)
     })
  }



}
