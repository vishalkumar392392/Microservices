import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeStudentComponent } from './welcome-student/welcome-student.component';
import { Route } from '@angular/compiler/src/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateStudentComponent } from './create-student/create-student.component';
import { FormsModule, FormGroup, ReactiveFormsModule } from "@angular/forms";
import { ExtraDeatailsComponent } from './extra-deatails/extra-deatails.component';
import { CompleteDetailsComponent } from './complete-details/complete-details.component';

const routes:Routes=[

  { path: "", component: WelcomeStudentComponent },
  {path:"add",component:CreateStudentComponent},
  {path:"details/:id",component:ExtraDeatailsComponent},
  {path:"completeDetails/:id",component:CompleteDetailsComponent}
  
]


@NgModule({
  declarations: [
    AppComponent,
    WelcomeStudentComponent,
    CreateStudentComponent,
    ExtraDeatailsComponent,
    CompleteDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,RouterModule.forRoot(routes),FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
