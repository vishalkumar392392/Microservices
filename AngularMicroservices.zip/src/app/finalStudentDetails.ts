export class FinalStudentDetails{
    instituteName:string;
    fatherName:string;
    motherName:string;
    postalCode:number;
    firstName:string;
    lastName:string;
    dateOfBirth:Date;
    className:number;
    port:number;
}